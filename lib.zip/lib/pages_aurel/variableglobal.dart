/*  String baseurlimage = "http://192.168.1.106:8000/assets/images/";
 final String baseUrl = 'http://192.168.1.106:8000/api';  */

 
 String baseurlimage = "http://backblogflutter.infinityfreeapp.com/assets/images/";
 final String baseUrl = 'http://backblogflutter.infinityfreeapp.com/api';
 final String eneamMap = "https://www.google.com/maps/place/Ecole+Nationale+d'Economie+Appliqu%C3%A9e+et+de+Management+(ENEAM)/@6.3643047,2.4085315,17z/data=!3m1!4b1!4m6!3m5!1s0x102355b22d4a54eb:0x78acee32e604e2d3!8m2!3d6.3643047!4d2.4085315!16s%2Fg%2F11cs31sp_7?entry=ttu&g_ep=EgoyMDI1MDIwMi4wIKXMDSoASAFQAw%3D%3D";

 